QR Multiplex Lab dataset
Generated 2026-10-21T19:49:56.091Z by https://amro2021.github.io/qr-transfer/multi/

Tables (join on run_id)
runs.csv    one row per run: label, distance, scheme and sender settings learned from the QR tags,
            receiver device, plus summary metrics.
slots.csv   one row per run and stream slot (R0 = red channel tile 1, L1 = black-and-white tile 2,
            b / e = base / enhancement layer).
files.csv   one row per run and transmitted file.
frames.csv  one row per processed camera frame.
qrs.csv     one row per QR code read.

Definitions
k                      sender frame counter carried in every QR code.
frame_loss             1 - distinct k read in this slot / (k_max - k_min + 1). Losses include sender frames the
                       camera never sampled, so compare proc_fps with sender_fps.
success_per_processed_frame
                       fraction of processed camera frames in which this slot was read at least once.
module_errors          raw module (pre-Reed-Solomon) errors: the decoded text is re-encoded with the sender's
                       library and error-correction level, and every module centre of the binary image the
                       decoder used is compared with it. Measured only on codes that were located and decoded,
                       so it is a conditional error rate; read it together with frame_loss.
mer_pooled             module_errors / modules_measured.
overhead               unique packets needed / K - 1 (LT fountain reception overhead).
complete_s             time from the first QR of a file to its verified reconstruction.
goodput_Bps            file size / complete_s.
sic_variant            index of the successive-interference-cancellation variant in use (layered scheme).
receive_filter         streams the receiver kept, as color/tile/layer (* = all).
Times are in milliseconds (t_ms) or seconds (_s) from the start of the run.
